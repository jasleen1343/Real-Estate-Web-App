import {createContext} from 'react'

const UserDetailContext = createContext()

export default UserDetailContext